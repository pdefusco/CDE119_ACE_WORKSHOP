import datetime

def tstampToString(tstamp):
    return str(datetime.datetime.fromtimestamp(tstamp))
